<?php
// footer.php
?>
<!DOCTYPE html>
<html>
    <head>
<link rel="stylesheet" href="style.css">
</head>
    <body>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Our Website. All rights reserved.</p>
    </footer>

</body>
</html>